<?php
$lang[''] = '';